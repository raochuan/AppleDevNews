# AppleDevNews

A [JSBox](https://apps.apple.com/us/app/id1312014438) script for https://developer.apple.com/news/